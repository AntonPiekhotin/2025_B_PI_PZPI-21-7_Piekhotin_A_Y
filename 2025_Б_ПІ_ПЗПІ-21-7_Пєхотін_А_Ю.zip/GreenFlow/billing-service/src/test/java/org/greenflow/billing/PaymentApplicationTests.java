package org.greenflow.billing;

import org.junit.jupiter.api.Test;

class PaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
