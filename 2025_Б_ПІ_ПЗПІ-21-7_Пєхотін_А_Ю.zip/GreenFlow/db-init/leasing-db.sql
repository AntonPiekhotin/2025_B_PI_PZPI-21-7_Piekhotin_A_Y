\c leasing-db
CREATE EXTENSION IF NOT EXISTS postgis;
