package org.greenflow.garden;

import org.junit.jupiter.api.Test;

class GardenApplicationTests {

    @Test
    void contextLoads() {
    }

}
