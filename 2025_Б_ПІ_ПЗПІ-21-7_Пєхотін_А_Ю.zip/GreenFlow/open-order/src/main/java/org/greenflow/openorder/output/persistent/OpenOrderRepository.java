package org.greenflow.openorder.output.persistent;

//public interface OpenOrderRepository {
//}
