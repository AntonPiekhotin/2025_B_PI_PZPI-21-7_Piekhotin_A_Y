package org.greenflow.openorder;

import org.junit.jupiter.api.Test;

class OpenOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
