package org.greenflow.authservice;

import org.junit.jupiter.api.Test;

class AuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
