package org.greenflow.authservice.model.entity.role;

public enum RoleType {
    ADMIN, MANAGER, CLIENT, WORKER
}
