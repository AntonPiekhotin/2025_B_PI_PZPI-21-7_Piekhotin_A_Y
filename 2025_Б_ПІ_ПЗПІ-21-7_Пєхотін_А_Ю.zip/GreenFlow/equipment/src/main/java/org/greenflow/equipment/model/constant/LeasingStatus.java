package org.greenflow.equipment.model.constant;

public enum LeasingStatus {
    PENDING,
    ACTIVE,
    CLOSED
}