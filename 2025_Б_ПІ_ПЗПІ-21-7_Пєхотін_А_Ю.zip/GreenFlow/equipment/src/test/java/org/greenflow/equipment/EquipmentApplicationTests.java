package org.greenflow.equipment;

import org.junit.jupiter.api.Test;

class EquipmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
