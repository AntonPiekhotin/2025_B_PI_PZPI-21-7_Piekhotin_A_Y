package org.greenflow.apigateway;

import org.junit.jupiter.api.Test;

class ApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
