package org.greenflow.client;

import org.junit.jupiter.api.Test;

class ClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
