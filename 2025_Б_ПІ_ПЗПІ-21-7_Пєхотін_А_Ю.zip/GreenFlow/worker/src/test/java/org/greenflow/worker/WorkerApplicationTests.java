package org.greenflow.worker;

import org.junit.jupiter.api.Test;

class WorkerApplicationTests {

    @Test
    void contextLoads() {
    }

}
