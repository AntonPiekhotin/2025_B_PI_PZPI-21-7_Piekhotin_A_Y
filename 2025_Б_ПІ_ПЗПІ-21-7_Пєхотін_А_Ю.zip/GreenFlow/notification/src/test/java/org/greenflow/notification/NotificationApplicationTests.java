package org.greenflow.notification;

import org.junit.jupiter.api.Test;

class NotificationApplicationTests {

    @Test
    void contextLoads() {
    }

}
