package org.greenflow.order;

import org.junit.jupiter.api.Test;

class OrderApplicationTests {

    @Test
    void contextLoads() {
    }

}
